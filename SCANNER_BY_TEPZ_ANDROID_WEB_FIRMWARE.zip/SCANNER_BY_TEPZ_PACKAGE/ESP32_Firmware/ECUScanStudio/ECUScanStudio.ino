#include <Arduino.h>
#include <NimBLEDevice.h>
#include <ArduinoJson.h>
#include "ProtocolDriver.h"

static const char* DEVICE_NAME = "SCANNER-BY-TEPZ";
static const char* SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
static const char* RX_UUID      = "6e400002-b5a3-f393-e0a9-e50e24dcca9e";
static const char* TX_UUID      = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";
static const char* FW_VERSION   = "1.0.0";

NimBLECharacteristic* txCharacteristic = nullptr;
String inputLine;
bool clientConnected = false;
bool simulationMode = true; // Safe default. Hardware mode requires a verified driver.
unsigned long lastLiveMs = 0;

void notifyJson(JsonDocument &doc) {
  String out; serializeJson(doc, out); out += "\n";
  if (clientConnected && txCharacteristic) {
    // Keep notifications below negotiated MTU in this simple line protocol.
    txCharacteristic->setValue((uint8_t*)out.c_str(), out.length());
    txCharacteristic->notify();
  }
}
void sendResult(int id, bool ok, JsonObject data, const char* error = nullptr) {
  StaticJsonDocument<512> doc;
  doc["id"] = id; doc["type"] = "result"; doc["ok"] = ok;
  if (data) doc["data"] = data;
  if (error) doc["error"] = error;
  notifyJson(doc);
}
void sendError(int id, const char* error) {
  StaticJsonDocument<256> doc;
  doc["id"] = id; doc["type"] = "result"; doc["ok"] = false; doc["error"] = error;
  notifyJson(doc);
}
void sendLive(const LiveData &d) {
  StaticJsonDocument<256> doc;
  doc["type"] = "live";
  JsonObject data = doc.createNestedObject("data");
  if (!isnan(d.rpm)) data["rpm"] = d.rpm;
  if (!isnan(d.tps)) data["tps"] = d.tps;
  if (!isnan(d.ect)) data["ect"] = d.ect;
  if (!isnan(d.map)) data["map"] = d.map;
  if (!isnan(d.battery)) data["battery"] = d.battery;
  notifyJson(doc);
}
LiveData simulatedData() {
  // DEMONSTRATION VALUES ONLY — not measured from a real ECU.
  static float phase = 0;
  phase += 0.13f;
  LiveData d;
  d.rpm = 1450 + 120 * sin(phase);
  d.tps = 2.0 + 0.5 * sin(phase * 0.7);
  d.ect = 32.0 + 0.1 * sin(phase * 0.2);
  d.map = 30.0 + 0.4 * sin(phase * 0.8);
  d.battery = 12.6;
  return d;
}
void handleCommand(const String &line) {
  StaticJsonDocument<512> req;
  DeserializationError err = deserializeJson(req, line);
  if (err) { sendError(0, "BAD_JSON"); return; }
  int id = req["id"] | 0;
  const char* cmd = req["cmd"] | "";
  if (!strcmp(cmd, "PING")) {
    StaticJsonDocument<256> doc; doc["id"]=id; doc["type"]="result"; doc["ok"]=true;
    JsonObject data=doc.createNestedObject("data"); data["device"]=DEVICE_NAME; data["version"]=FW_VERSION;
    notifyJson(doc);
  } else if (!strcmp(cmd, "GET_STATUS")) {
    StaticJsonDocument<256> doc; doc["id"]=id; doc["type"]="result"; doc["ok"]=true;
    JsonObject data=doc.createNestedObject("data"); data["device"]=DEVICE_NAME;
    data["version"]=FW_VERSION; data["mode"]=simulationMode?"SIM":"HW";
    data["ecuDriver"]="NONE"; data["ecuConnected"]=false;
    notifyJson(doc);
  } else if (!strcmp(cmd, "SET_MODE")) {
    const char* mode=req["mode"]|"SIM";
    if (!strcmp(mode,"SIM")) simulationMode=true;
    else if (!strcmp(mode,"HW")) {
      simulationMode=false;
      // No generic driver is enabled by default. Commands safely report unsupported.
    } else { sendError(id,"INVALID_MODE"); return; }
    StaticJsonDocument<128> doc;doc["id"]=id;doc["type"]="result";doc["ok"]=true;
    JsonObject data=doc.createNestedObject("data");data["mode"]=simulationMode?"SIM":"HW";
    notifyJson(doc);
  } else if (!strcmp(cmd, "READ_LIVE")) {
    if (simulationMode) { sendLive(simulatedData()); StaticJsonDocument<128> ack; ack["id"]=id; ack["type"]="result"; ack["ok"]=true; JsonObject data=ack.createNestedObject("data"); data["stream"]="sample_sent"; notifyJson(ack); }
    else { sendError(id,"NOT_IMPLEMENTED: install a verified ECU protocol driver"); }
  } else if (!strcmp(cmd, "READ_DTC")) {
    if (simulationMode) {
      StaticJsonDocument<256> doc;doc["id"]=id;doc["type"]="result";doc["ok"]=true;
      JsonObject data=doc.createNestedObject("data");JsonArray codes=data.createNestedArray("codes");
      notifyJson(doc);
    } else { sendError(id,"NOT_IMPLEMENTED: install a verified ECU protocol driver"); }
  } else if (!strcmp(cmd, "CLEAR_DTC")) {
    sendError(id,"DISABLED: clearing DTC requires ECU-specific verified implementation and explicit safety review");
  } else {
    sendError(id,"UNKNOWN_COMMAND");
  }
}
class ServerCallbacks : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer*, NimBLEConnInfo&) override { clientConnected=true; }
  void onDisconnect(NimBLEServer*, NimBLEConnInfo&, int) override {
    clientConnected=false; NimBLEDevice::startAdvertising();
  }
};
class RxCallbacks : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic* c, NimBLEConnInfo&) override {
    std::string value=c->getValue();
    for (char ch : value) {
      if (ch=='\n') { inputLine.trim(); if(inputLine.length()) handleCommand(inputLine); inputLine=""; }
      else if (ch!='\r' && inputLine.length()<500) inputLine += ch;
      else if (inputLine.length()>=500) inputLine="";
    }
  }
};
void setup() {
  Serial.begin(115200);
  NimBLEDevice::init(DEVICE_NAME);
  NimBLEServer* server=NimBLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  NimBLEService* service=server->createService(SERVICE_UUID);
  txCharacteristic=service->createCharacteristic(TX_UUID,NIMBLE_PROPERTY::NOTIFY);
  NimBLECharacteristic* rx=service->createCharacteristic(RX_UUID,NIMBLE_PROPERTY::WRITE|NIMBLE_PROPERTY::WRITE_NR);
  rx->setCallbacks(new RxCallbacks());
  service->start();
  NimBLEAdvertising* advertising=NimBLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->start();
  Serial.println("SCANNER BY TEPZ BLE ready. SIM mode is default.");
}
void loop() {
  delay(10);
}
