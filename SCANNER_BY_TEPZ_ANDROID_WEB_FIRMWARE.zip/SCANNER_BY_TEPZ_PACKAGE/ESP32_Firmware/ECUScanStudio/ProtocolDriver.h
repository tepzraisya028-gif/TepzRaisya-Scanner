#pragma once
#include <Arduino.h>

// Implement only after verifying the exact ECU, connector, electrical interface,
// initialization sequence, addressing and service definitions.
// Never treat this generic interface as proof of universal ECU compatibility.
struct LiveData {
  float rpm = NAN;
  float tps = NAN;
  float ect = NAN;
  float map = NAN;
  float battery = NAN;
};

class ProtocolDriver {
public:
  virtual ~ProtocolDriver() {}
  virtual const char* name() = 0;
  virtual bool begin() = 0;
  virtual bool readLive(LiveData &out) = 0;
  virtual bool readDtc(String &jsonArray) = 0;
};
