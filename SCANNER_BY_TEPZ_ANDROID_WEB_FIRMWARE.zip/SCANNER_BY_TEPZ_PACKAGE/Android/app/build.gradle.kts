plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ecuscanstudio.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tepz.scannerbytepz"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.1"
    }
}
