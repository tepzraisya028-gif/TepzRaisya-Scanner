package com.ecuscanstudio.app

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.nio.charset.Charset
import java.util.UUID

class MainActivity : Activity() {
    private val serviceId = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
    private val rxId = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e") // write from phone
    private val txId = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e") // notify to phone
    private val cccdId = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val handler = Handler(Looper.getMainLooper())
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var scanning = false
    private var lineBuffer = ""
    private var commandId = 0
    private var streamOn = false
    private var streamTask: Runnable? = null

    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var connectButton: Button
    private lateinit var mode: TextView
    private lateinit var rpm: TextView
    private lateinit var tps: TextView
    private lateinit var ect: TextView
    private lateinit var map: TextView
    private lateinit var battery: TextView
    private lateinit var log: TextView
    private lateinit var bluetoothAdapter: BluetoothAdapter

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.device.name ?: result.scanRecord?.deviceName ?: ""
            if (name == "SCANNER-BY-TEPZ" || result.scanRecord?.serviceUuids?.any { it.uuid == serviceId } == true) {
                stopScan()
                connectDevice(result.device)
            }
        }
        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { setStatus("BLE scan gagal: $errorCode") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 13, 23)
        window.navigationBarColor = Color.rgb(8, 13, 23)
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(18))
            setBackgroundColor(Color.rgb(8, 13, 23))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        val brand = TextView(this).apply {
            text = "SCANNER BY TEPZ\nUNIVERSAL MOTORCYCLE DIAGNOSTICS"
            setTextColor(Color.rgb(55, 213, 242)); textSize = 18f
            setPadding(0, 0, 0, dp(18))
        }
        content.addView(brand)
        content.addView(label("UNIVERSAL BLE DIAGNOSTICS", 10, Color.rgb(130,145,168)))
        status = label("●  DISCONNECTED", 14, Color.rgb(255,180,92))
        status.setPadding(0, dp(12), 0, dp(12)); content.addView(status)
        mode = label("MODE: HARDWARE LINK · ECU DRIVER BELUM DIPILIH", 10, Color.LTGRAY)
        content.addView(mode)
        connectButton = Button(this).apply {
            text = "CONNECT ESP32 BLE"
            setOnClickListener { if (gatt == null) startScan() else disconnect() }
        }
        content.addView(connectButton, matchWrap())
        content.addView(section("LIVE DATA"))
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rpm = metric("ENGINE SPEED", "— RPM")
        tps = metric("THROTTLE POSITION", "— %")
        ect = metric("ENGINE TEMPERATURE", "— °C")
        map = metric("INTAKE PRESSURE", "— kPa")
        battery = metric("BATTERY VOLTAGE", "— V")
        listOf(rpm,tps,ect,map,battery).forEach { grid.addView(it) }
        content.addView(grid)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(section("DIAGNOSTIC ACTIONS"))
        actions.addView(actionButton("READ LIVE DATA") { sendCommand("READ_LIVE") })
        actions.addView(actionButton("READ DTC") { sendCommand("READ_DTC") })
        actions.addView(actionButton("ECU / DEVICE STATUS") { sendCommand("GET_STATUS") })
        actions.addView(actionButton("START / STOP LIVE STREAM") { toggleStream() })
        content.addView(actions)
        content.addView(section("ACTIVITY LOG"))
        log = label("Belum ada aktivitas.", 11, Color.rgb(150,166,188))
        log.setPadding(dp(12), dp(12), dp(12), dp(12))
        log.setBackgroundColor(Color.rgb(16,26,42))
        content.addView(log)
        content.addView(label("Catatan: data SIM adalah data contoh. Pembacaan ECU nyata memerlukan driver protokol, kabel/interface, dan pinout yang terverifikasi.", 10, Color.rgb(255,180,92)).apply {
            setPadding(0, dp(18), 0, dp(8))
        })
        root.addView(scroll, LinearParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(textValue: String, size: Int, color: Int) = TextView(this).apply {
        text = textValue; textSize = size.toFloat(); setTextColor(color)
    }
    private fun section(t: String) = TextView(this).apply {
        text = t; textSize = 12f; setTextColor(Color.rgb(55,213,242))
        setPadding(0, dp(22), 0, dp(10))
    }
    private fun metric(title: String, initial: String) = TextView(this).apply {
        text = "$title\n$initial"; textSize = 16f; setTextColor(Color.WHITE)
        setPadding(dp(14), dp(14), dp(14), dp(14))
        setBackgroundColor(Color.rgb(16,26,42))
        val lp = LinearParams(-1, -2); lp.bottomMargin = dp(8); layoutParams = lp
    }
    private fun actionButton(t: String, action: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { action() }
    }
    private fun matchWrap() = LinearParams(-1, -2)
    private fun LinearParams(w: Int, h: Int, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun requestBlePermissions() {
        val missing = requiredPermissions().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 20)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.any { it != PackageManager.PERMISSION_GRANTED }) setStatus("Izin Bluetooth diperlukan")
    }

    private fun startScan() {
        if (requiredPermissions().any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestBlePermissions(); return
        }
        if (!bluetoothAdapter.isEnabled) { setStatus("Aktifkan Bluetooth Android terlebih dahulu"); return }
        scanner = bluetoothAdapter.bluetoothLeScanner
        if (scanner == null) { setStatus("BLE scanner tidak tersedia"); return }
        setStatus("Mencari SCANNER-BY-TEPZ…")
        connectButton.isEnabled = false
        scanning = true
        val filter = ScanFilter.Builder().setServiceUuid(android.os.ParcelUuid(serviceId)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner?.startScan(listOf(filter), settings, scanCallback)
        handler.postDelayed({
            if (scanning) {
                stopScan(); connectButton.isEnabled = true
                setStatus("Perangkat tidak ditemukan. Pastikan ESP32 menyala.")
            }
        }, 12000)
    }
    private fun stopScan() {
        if (scanning) { try { scanner?.stopScan(scanCallback) } catch (_: Exception) {} }
        scanning = false
    }
    private fun connectDevice(device: BluetoothDevice) {
        setStatus("Menghubungkan ke ${device.name ?: "ESP32"}…")
        gatt = if (Build.VERSION.SDK_INT >= 23) device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
               else device.connectGatt(this, false, gattCallback)
    }
    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread {
                    gatt = null; writeChar = null; notifyChar = null
                    connectButton.text = "CONNECT ESP32 BLE"; connectButton.isEnabled = true
                    setStatus("●  DISCONNECTED")
                }
                g.close()
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(serviceId)
            writeChar = service?.getCharacteristic(rxId)
            notifyChar = service?.getCharacteristic(txId)
            if (writeChar == null || notifyChar == null) {
                runOnUiThread { setStatus("Service BLE UART tidak cocok") }; return
            }
            g.setCharacteristicNotification(notifyChar, true)
            val descriptor = notifyChar?.getDescriptor(cccdId)
            if (descriptor != null) {
                if (Build.VERSION.SDK_INT >= 33) g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                else {
                    @Suppress("DEPRECATION")
                    descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    @Suppress("DEPRECATION")
                    g.writeDescriptor(descriptor)
                }
            }
            runOnUiThread {
                connectButton.text = "DISCONNECT BLE"; connectButton.isEnabled = true
                setStatus("●  CONNECTED · ${g.device.name ?: "ESP32"}")
                appendLog("BLE connected. Menunggu data scanner.")
            }
            sendCommand("PING")
        }
        @Deprecated("Deprecated in Android 13")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            handleNotify(characteristic.value)
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            handleNotify(value)
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, statusCode: Int) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) runOnUiThread { appendLog("BLE write error: $statusCode") }
        }
    }

    private fun handleNotify(bytes: ByteArray) {
        lineBuffer += bytes.toString(Charset.forName("UTF-8"))
        while (lineBuffer.contains("\n")) {
            val idx = lineBuffer.indexOf('\n')
            val line = lineBuffer.substring(0, idx).trim()
            lineBuffer = lineBuffer.substring(idx + 1)
            if (line.isNotEmpty()) try {
                val obj = JSONObject(line)
                if (obj.optString("type") == "live") {
                    val d = obj.optJSONObject("data") ?: JSONObject()
                    runOnUiThread { updateMetrics(d) }
                } else if (obj.optString("type") == "result") {
                    runOnUiThread {
                        val ok = obj.optBoolean("ok")
                        val data = obj.optJSONObject("data")
                        if (data != null && data.has("version")) appendLog("ESP32 firmware ${data.optString("version")}")
                        if (!ok) appendLog("ERROR: ${obj.optString("error")}")
                        else if (data?.has("codes") == true) appendLog("DTC: ${data.optJSONArray("codes")}")
                        else if (data?.has("mode") == true) mode.text = "MODE: ${data.optString("mode")}"
                    }
                }
            } catch (_: Exception) { runOnUiThread { appendLog("Data BLE tidak valid") } }
        }
    }
    private fun updateMetrics(d: JSONObject) {
        fun value(k: String, suffix: String): String =
            if (d.has(k)) "${d.optDouble(k).let { String.format("%.1f", it) }} $suffix" else "— $suffix"
        rpm.text = "ENGINE SPEED\n${if(d.has("rpm")) d.optDouble("rpm").toInt().toString()+" RPM" else "— RPM"}"
        tps.text = "THROTTLE POSITION\n${value("tps","%")}"
        ect.text = "ENGINE TEMPERATURE\n${value("ect","°C")}"
        map.text = "INTAKE PRESSURE\n${value("map","kPa")}"
        battery.text = "BATTERY VOLTAGE\n${value("battery","V")}"
    }
    private fun sendCommand(cmd: String) {
        val ch = writeChar
        if (gatt == null || ch == null) { appendLog("Hubungkan ESP32 BLE terlebih dahulu"); return }
        val payload = JSONObject().put("id", ++commandId).put("cmd", cmd).toString() + "\n"
        val bytes = payload.toByteArray(Charsets.UTF_8)
        if (Build.VERSION.SDK_INT >= 33) {
            gatt?.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
        } else {
            @Suppress("DEPRECATION")
            ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            @Suppress("DEPRECATION")
            ch.value = bytes
            @Suppress("DEPRECATION")
            gatt?.writeCharacteristic(ch)
        }
        appendLog("Command sent: $cmd")
    }
    private fun toggleStream() {
        if (streamOn) {
            streamTask?.let { handler.removeCallbacks(it) }; streamOn = false
            appendLog("Live stream stopped")
        } else {
            streamOn = true
            val task = object : Runnable {
                override fun run() {
                    if (!streamOn) return
                    sendCommand("READ_LIVE")
                    handler.postDelayed(this, 1000)
                }
            }
            streamTask = task; handler.post(task); appendLog("Live stream started")
        }
    }
    private fun disconnect() {
        streamOn = false; streamTask?.let { handler.removeCallbacks(it) }
        stopScan(); gatt?.disconnect(); gatt?.close(); gatt = null
        writeChar = null; notifyChar = null
        connectButton.text = "CONNECT ESP32 BLE"; connectButton.isEnabled = true
        setStatus("●  DISCONNECTED")
    }
    private fun setStatus(s: String) { status.text = s }
    private fun appendLog(s: String) {
        log.text = (s + "\n" + log.text).take(900)
    }
    override fun onDestroy() { disconnect(); super.onDestroy() }
}
