# ECU SCAN STUDIO Android

Native Android starter project (Kotlin) for Android 10+ (minSdk 29), using BLE GATT UART to communicate with the ESP32 firmware from ECU SCAN STUDIO BLE V1.

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`ECU_SCAN_STUDIO_ANDROID`) in Android Studio.
3. Allow Gradle sync and install any prompted SDK/build tools.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

For a signed release: Build > Generate Signed Bundle / APK.

## BLE UUID
Service: `6e400001-b5a3-f393-e0a9-e50e24dcca9e`
Write to ESP32 RX: `6e400002-b5a3-f393-e0a9-e50e24dcca9e`
Notifications from ESP32 TX: `6e400003-b5a3-f393-e0a9-e50e24dcca9e`

Device name / service UUID filter: ECU-SCAN-STUDIO.

## Compatibility
- minSdk 29 = Android 10.
- Android 10/11 requests location permission for BLE scan.
- Android 12+ requests BLUETOOTH_SCAN and BLUETOOTH_CONNECT.
- Bluetooth must be enabled and ESP32 firmware advertising the documented service.

## Limitations
This is an Android BLE client starter, not a universal ECU protocol implementation. It connects to the ESP32 and exchanges JSON-line commands. Real motorcycle ECU live data/DTC requires a verified ECU-specific protocol driver and suitable protected K-Line/CAN hardware. Simulation values must not be interpreted as measured engine data.

## Note
No APK binary is included from this source package. Build it with Android Studio using the steps above.
