SCANNER BY TEPZ — PAKET PROYEK

Isi:
- Android/: aplikasi Android native Kotlin (minimum Android 10 / API 29)
- Web/: antarmuka web BLE
- ESP32_Firmware/: firmware ESP32 BLE UART
- .github/workflows/build-android-apk.yml: workflow untuk membangun APK debug secara otomatis di GitHub Actions

CARA MENGHASILKAN APK:
1. Ekstrak ZIP ini.
2. Buat repository GitHub baru dan upload seluruh isi folder ini (termasuk folder .github).
3. Buka tab Actions di repository, pilih "Build Scanner by Tepz APK", lalu klik Run workflow.
4. Setelah proses selesai, buka hasil run tersebut dan unduh artifact bernama "Scanner-by-Tepz-APK". Di dalamnya ada app-debug.apk.

CATATAN PENTING:
- File APK belum disertakan karena lingkungan ini tidak memiliki Android SDK/Gradle untuk mengompilasi aplikasi secara langsung.
- Workflow GitHub akan mengompilasi APK debug otomatis; perlu akun GitHub dan satu kali menjalankan workflow.
- Aplikasi mendukung koneksi BLE ke ESP32 dengan UUID UART yang ada di firmware.
- Mode contoh/simulasi aktif secara default. Ini belum merupakan scanner universal yang bisa membaca semua ECU. Pembacaan ECU nyata memerlukan driver protokol dan pinout yang sudah diverifikasi untuk model motor tertentu.
- BLE device name firmware: SCANNER-BY-TEPZ. Flash firmware ini ke ESP32 agar aplikasi dapat menemukannya.
